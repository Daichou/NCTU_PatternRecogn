function o = deReLu(s)
    o = (s > 0);
end
