function o = ReLu(s)
    o = max(s,0);
end
