function o = deSigmoid(s)
    o = s*(1.0-s);
end
