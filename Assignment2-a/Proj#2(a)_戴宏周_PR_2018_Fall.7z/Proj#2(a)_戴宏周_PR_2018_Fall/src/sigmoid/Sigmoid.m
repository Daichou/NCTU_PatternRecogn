function o = Sigmoid(s)
    o = 1/(1+exp(-s));
end
